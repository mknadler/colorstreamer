(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tommyjs:colpick'] = {};

})();

//# sourceMappingURL=tommyjs_colpick.js.map
